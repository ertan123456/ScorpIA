import express from "express";
import path from "path";
import { fileURLToPath } from "url";

import { makeOpenAIClient, safeParseJson } from "./openai.js";
import { ROUTER_SYS, FRC_SYS, ARCH_SYS } from "./prompts.js";

const app = express();
app.use(express.json({ limit: "1mb" }));

const client = makeOpenAIClient();
const PORT = Number(process.env.PORT || 3000);

// --- (Opsiyonel) web klasörünü servis edelim:
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const webDir = path.resolve(__dirname, "../../web");
app.use("/", express.static(webDir));

// Health check
app.get("/health", (req, res) => res.json({ ok: true }));

app.post("/ask", async (req, res) => {
  try {
    const question = (req.body?.question ?? "").toString().trim();
    if (!question) return res.json({ answer: "" });

    // 1) Router (temperature=0)
    const r = await client.chat.completions.create({
      model: "gpt-4.1-mini",
      messages: [
        { role: "system", content: ROUTER_SYS },
        { role: "user", content: question }
      ],
      temperature: 0
    });

    const raw = r.choices?.[0]?.message?.content ?? "";
    const parsed = safeParseJson(raw);
    const label = parsed?.label ?? "other";

    // 2) other => boş dön
    if (label === "other") return res.json({ answer: "" });

    // 3) uzman cevap
    const sys = label === "frc" ? FRC_SYS : ARCH_SYS;

    const a = await client.chat.completions.create({
      model: "gpt-4.1",
      messages: [
        { role: "system", content: sys },
        { role: "user", content: question }
      ],
      temperature: 0.3
    });

    const answer = (a.choices?.[0]?.message?.content ?? "").trim();
    return res.json({ answer });
  } catch (err) {
    // Güvenli hata (key sızdırma vs yok)
    return res.status(500).json({
      answer: "",
      error: "Server error",
      details: String(err?.message ?? err)
    });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running: http://localhost:${PORT}`);
});
