import OpenAI from "openai";

export function makeOpenAIClient() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) {
    throw new Error("OPENAI_API_KEY is missing. Put it in server/.env");
  }
  return new OpenAI({ apiKey: key });
}

export function safeParseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}
